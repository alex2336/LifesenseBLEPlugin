//
//  AppDelegate.h
//  Demo
//
//  Created by 1 on 5/15/14.
//  Copyright (c) 2014 LS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DemoViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
