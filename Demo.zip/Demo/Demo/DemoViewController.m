//
//  DemoViewController.m
//  A2Demo
//
//  Created by 1 on 5/15/14.
//  Copyright (c) 2014 LS. All rights reserved.
//

#import "DemoViewController.h"



@interface DemoViewController ()

@end

@implementation DemoViewController

#pragma mark - Private

- (void)logText:(NSString *)text {
    [self.logView setText:[NSString stringWithFormat:@"%@\n%@",self.logView.text,text]];
}

#pragma mark - LSHardwareConnectorDelegate

- (PedometerUserDownLoadInfo *)hardwareConnectorGetPedometerDownloadInfoForSensor:(LSHardwareSensor *)sensor {
    PedometerUserDownLoadInfo *info = [PedometerUserDownLoadInfo new];
    info.height = 1.70;
    info.stride = 0.78;
    info.weekStart = 1;
    info.weekTargetCalories = 0;
    info.weekTargetDistance = 0;
    info.weekTargetExerciseAmount = 2;
    info.weekTargetSteps = 14000;
    info.weight = 65.5;
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self logText:@"配置计步器下载信息"];
    });
    
    return info;
}


-(void)pairConnectorDiscoveredPairingSensor:(LSHardwareSensor*)sensor {
    NSLog(@"hardwareConnectorDiscoveredPairingSensor");
    [self logText:@"发现配对模式设备，自动配对"];
    //auto Pair
    [[LSHardwareConnector shareConnector] pairWithHardwareSensor:sensor];
    
}

-(void)pairConnectorPairedSensor:(LSHardwareSensor*)sensor withState:(BOOL)state {
    [self logText:@"配对成功"];
    NSLog(@"hardwareConnectorPairedSensor");
}


/**
 *  接收体重秤数据回调
 *
 *  @param data 体重秤数据
 */
-(void)hardwareConnectorReceiveWeightMeasurementData:(WeightData*)data {
    [self logText:@"\n收到体重秤数据"];
    [self logText:[NSString stringWithFormat:@"weight %f",data.weight]];
    [self logText:[NSString stringWithFormat:@"pbf%f",data.pbf]];
    NSLog(@"hardwareConnectorPairedSensor");
    
}

/**
 *  接收计步器数据回调
 *
 *  @param data 计步器数据
 */-(void)hardwareConnectorReceivePedometerMeasurementData:(PedometerData*)data {
     [self logText:@"\n收到计步器数据"];
     [self logText:[NSString stringWithFormat:@"walkSteps %ld",(long)data.walkSteps]];
     [self logText:[NSString stringWithFormat:@"runSteps %ld",(long)data.runSteps]];
 }

/**
 *  接收血压计数据回调
 *
 *  @param data 血压计数据
 */
-(void)hardwareConnectorReceiveBloodPressureMeasurementData:(BloodPressureData *)data {
     [self logText:@"\n收到血压计数据"];
    [self logText:[NSString stringWithFormat:@"systolic %ld",(long)data.systolic]];
    [self logText:[NSString stringWithFormat:@"diastolic %ld",(long)data.diastolic]];
    [self logText:[NSString stringWithFormat:@"pluseRate %ld",(long)data.pluseRate]];

}

/**
 *  接收厨房称数据回调
 *
 *  @param data 厨房称数据
 */
-(void)hardwareConnectorReceiveKitchenScaleMeasurementData:(KitchenScaleData*)data{
     [self logText:@"\n收到厨房称数据"];
    
}

/**
 *  接收身高数据回调
 *
 *  @param data 身高数据
 */
-(void)hardwareConnectorReceiveHeightMeasurementData:(HeightData*)data {
     [self logText:@"\n收到身高数据"];
}

/**
 *  接收通用体重秤数据回调
 *
 *  @param data 体重秤数据
 */
-(void)hardwareConnectorReceiveGeneralWeightMeasurementData:(WeightData*)data {
      [self logText:@"\n收到体重秤数据"];
    
}

#pragma mark - ViewLifeCycle
#pragma mark -IBAction

- (IBAction)scanBtnAction:(id)sender {
//    [[LSHardwareConnector shareConnector] cancelScanning];
    [self logText:@"开始扫描"];
    [[LSHardwareConnector shareConnector] startScanningWithDelegate:self withEnalbeSensorTypes:@[[NSNumber numberWithInt:LS_SENSOR_TYPE_PEDOMETER],[NSNumber numberWithInt:LS_SENSOR_TYPE_WEIGHT_SCALE],[NSNumber numberWithInt:LS_SENSOR_TYPE_GENERAL_WEIGHT_SCALE],[NSNumber numberWithInt:LS_SENSOR_TYPE_BLOODPRESSURE]]];
}

- (IBAction)stopScanBtnAction:(id)sender {
    [self logText:@"停止扫描"];
    [[LSHardwareConnector shareConnector] cancelScanning];
}

- (IBAction)clearLogBtnAction:(id)sender {
    [self.logView setText:@""];
}

- (IBAction)searchDeviceBtnAction:(id)sender {
    NSArray *pairedDevices = [[LSHardwareConnector shareConnector] pairedSensors];
    [self logText:[NSString stringWithFormat:@"Paired Count %lu",(unsigned long)pairedDevices.count]];
    for (LSHardwareSensor *sensor in pairedDevices) {
        [self logText:[NSString stringWithFormat:@"Paired DeviceName %@",sensor.sensorName]];
    }
}

- (IBAction)forgetDeviceBtnAction:(id)sender {
    NSArray *pairedDevices = [[LSHardwareConnector shareConnector] pairedSensors];
    for (LSHardwareSensor *sensor in pairedDevices) {
        [[LSHardwareConnector shareConnector] forgetPairedSensorWithSensor:sensor];
    }
    [self searchDeviceBtnAction:nil];
}
@end
