//
//  DemoViewController.h
//  A2Demo
//
//  Created by 1 on 5/15/14.
//  Copyright (c) 2014 LS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <LSBLE__A2/LSBLE_A2.h>

@interface DemoViewController : UIViewController <LSHardwareConnectorDelegate>
@property (weak, nonatomic) IBOutlet UITextView *logView;

- (IBAction)scanBtnAction:(id)sender;
- (IBAction)stopScanBtnAction:(id)sender;
- (IBAction)clearLogBtnAction:(id)sender;
- (IBAction)searchDeviceBtnAction:(id)sender;
- (IBAction)forgetDeviceBtnAction:(id)sender;

@end
